import java.util.Arrays;

public class App {

    public static void main(String[] args) {
        String[] s = "word".split("");

        System.out.println(Arrays.toString(s));
    }
}
