package comparatorandcomparable;public class ComparableExample {
}
