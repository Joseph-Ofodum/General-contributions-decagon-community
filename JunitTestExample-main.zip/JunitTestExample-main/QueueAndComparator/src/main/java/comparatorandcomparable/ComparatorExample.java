package comparatorandcomparable;public class ComparatorExample {
}
