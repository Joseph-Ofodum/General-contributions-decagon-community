package schoolapp.pupils;

import schoolapp.course.Course;

public interface Learnable {

    void takeCourse(Course course);
}
