package schoolapp.staffs;

import schoolapp.pupils.Applicant;

public interface Academic extends Admittable {


}
