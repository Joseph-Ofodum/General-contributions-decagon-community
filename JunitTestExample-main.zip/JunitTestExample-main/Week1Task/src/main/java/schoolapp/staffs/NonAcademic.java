package schoolapp.staffs;

public interface NonAcademic {



}
