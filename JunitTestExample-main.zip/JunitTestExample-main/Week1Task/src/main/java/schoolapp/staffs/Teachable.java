package schoolapp.staffs;

public interface Teachable {

    void teachStudent(Staff teacher);
}
