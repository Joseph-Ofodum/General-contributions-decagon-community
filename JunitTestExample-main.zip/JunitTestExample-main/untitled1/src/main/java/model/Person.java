package model;

public class Person {
}
